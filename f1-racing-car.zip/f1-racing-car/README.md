# F1 Racing Car – Learning Project

An animated Formula 1 car built with plain HTML, CSS and JavaScript, packaged with Nginx in Docker and deployed to Kubernetes. No frameworks, no build step, no external dependencies.

What it does: the car drives onto the track when the page loads. Press **Start race** to run the five start lights; when they go out the car launches. Hold **Accelerate** or **Brake** (or use ↑/W and ↓/S). The wheels turn in sync with the road, the track scrolls in parallax layers, the car squats under throttle and dives under braking, the DRS flap opens above 280 km/h, and the rear rain light flashes while braking.

## Project structure

```text
f1-racing-car/
├── index.html        # Page and car structure (the car is made of <div>s)
├── style.css         # All visuals, the --car-color variable, animations
├── script.js         # Physics loop, controls, start lights
├── Dockerfile        # Nginx (unprivileged, Alpine) image
├── .dockerignore     # Keeps the image build context tiny
├── deployment.yaml   # Kubernetes Deployment (2 replicas)
├── service.yaml      # Kubernetes Service (NodePort 30080)
└── README.md
```

---

## 1. Run the application locally

The simplest option is to double-click `index.html` to open it in a browser. Nothing else is needed.

To serve it like a real website, start any static server inside the project folder:

```bash
cd f1-racing-car

# Python 3
python3 -m http.server 8000

# or Node.js
npx serve .
```

Then open <http://localhost:8000>.

---

## 2. Change the car's color with a CSS variable

Open `style.css` and find this near the top:

```css
:root {
    --car-color: #ff0000;
}
```

Change the value and refresh the page:

```css
:root {
    --car-color: #0000ff;   /* blue */
}
```

That one line repaints the bodywork, wings, cockpit, helmet stripe, wheel hubs and even the speed gauge's accent. No HTML or JavaScript changes are needed.

**How it works:**

- Every coloured part uses `var(--car-color)`.
- The lighter and darker shades used for highlights and shadows are calculated from it inside `.car`, using `color-mix()`:
  ```css
  --car-dark:  color-mix(in srgb, var(--car-color) 65%, #000);
  --car-light: color-mix(in srgb, var(--car-color) 70%, #fff);
  ```
  So when the base color changes, every shade follows automatically.
- `@property --car-color { syntax: "<color>"; ... }` registers the variable as a real color. That lets the browser animate it, so color changes fade smoothly. A side effect: if you type an invalid value, the car falls back to the `initial-value` (red).

Other variables you can try in the same block: `--accent-color` (stripe and number), `--tyre-color` (sidewall band: `#e8202a` soft, `#ffd12a` medium, `#f2f2f2` hard) and `--helmet-color`.

The **Car color** picker on the page is only a live preview. It sets a temporary inline style on `<html>`; **Reset** removes it and returns to the value in `style.css`. The permanent color always lives in the stylesheet.

---

## 3. Build the Docker image

```bash
cd f1-racing-car
docker build -t f1-racing-car:1.0.0 .
```

Check the image size (it should be roughly 50 MB or less):

```bash
docker images f1-racing-car
```

Why this image is lightweight and safe:

- **Small base:** `nginxinc/nginx-unprivileged:*-alpine`.
- **Non-root:** Nginx runs as user `101` and listens on port `8080`.
- **Read-only content:** site files are owned by root with mode `0644`, so the server can read but not change them.
- **Minimal context:** `.dockerignore` sends only the three web files to the build.
- **Pinned version:** the base tag is fixed for repeatable builds. Check Docker Hub for newer stable tags from time to time.

---

## 4. Run the application with Docker

```bash
docker run -d --name f1-car -p 8080:8080 f1-racing-car:1.0.0
```

Open <http://localhost:8080>.

Useful commands:

```bash
docker ps                      # STATUS shows "(healthy)" after ~30 s
docker logs f1-car             # Nginx access logs
docker stop f1-car && docker rm f1-car
```

For extra hardening you can also run it with a read-only filesystem, the same way Kubernetes does:

```bash
docker run -d --name f1-car -p 8080:8080 \
  --read-only --tmpfs /tmp --cap-drop ALL \
  --security-opt no-new-privileges \
  f1-racing-car:1.0.0
```

---

## 5. Deploy to Kubernetes

### Step 1: Make the image available to the cluster

The cluster must be able to find `f1-racing-car:1.0.0`. Choose the option that matches your setup:

| Cluster | Command |
|---|---|
| **minikube** | `minikube image load f1-racing-car:1.0.0` |
| **kind** | `kind load docker-image f1-racing-car:1.0.0` |
| **Docker Desktop** | Nothing to do; it shares images with Docker |
| **Remote / cloud cluster** | Push to a registry (below) |

Pushing to a registry (Docker Hub example):

```bash
docker tag f1-racing-car:1.0.0 <your-user>/f1-racing-car:1.0.0
docker push <your-user>/f1-racing-car:1.0.0
```

Then change the `image:` line in `deployment.yaml` to `<your-user>/f1-racing-car:1.0.0`.

### Step 2: Apply the manifests

```bash
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
```

### Step 3: Check that it's running

```bash
kubectl get deployments
kubectl get pods -l app=f1-racing-car      # both pods should be Running, READY 1/1
kubectl get service f1-racing-car
```

What the Deployment sets up:

- **2 replicas** with rolling updates that never drop below two ready pods.
- **Readiness and liveness probes** on `/`, so traffic only goes to healthy pods and stuck ones restart.
- **Resource requests and limits** so the app can't starve other workloads.
- **Security context:** non-root user, no privilege escalation, all Linux capabilities dropped, read-only root filesystem, and the default seccomp profile. A small `emptyDir` at `/tmp` gives Nginx the one writable folder it needs.

---

## 6. Access the application through the Service

The Service is type `NodePort`: it listens on port `80` inside the cluster and on port `30080` on every node.

| Cluster | How to open the app |
|---|---|
| **minikube** | `minikube service f1-racing-car --url`, then open the printed URL |
| **Docker Desktop** | <http://localhost:30080> |
| **Any cluster (works everywhere)** | `kubectl port-forward service/f1-racing-car 8080:80`, then open <http://localhost:8080> |
| **Cluster with reachable nodes** | `http://<node-ip>:30080` (find the IP with `kubectl get nodes -o wide`) |

On **kind**, node ports aren't exposed to your machine by default, so use `kubectl port-forward`.

On a **cloud cluster** (EKS, GKE, AKS) you can change `type: NodePort` to `type: LoadBalancer` in `service.yaml` (and remove the `nodePort` line), re-apply, and use the `EXTERNAL-IP` from `kubectl get service f1-racing-car`.

---

## Managing the deployment

```bash
# Scale up or down
kubectl scale deployment f1-racing-car --replicas=3

# Ship a new version: rebuild with a new tag, load/push it, then
kubectl set image deployment/f1-racing-car web=f1-racing-car:1.0.1
kubectl rollout status deployment/f1-racing-car

# Undo the last rollout
kubectl rollout undo deployment/f1-racing-car

# Remove everything
kubectl delete -f service.yaml -f deployment.yaml
```

## Troubleshooting

| Symptom | Likely cause and fix |
|---|---|
| Pod shows `ImagePullBackOff` or `ErrImagePull` | The cluster can't find the image. Load it (minikube/kind) or push it and update `image:` in `deployment.yaml`. |
| Pod shows `CreateContainerConfigError` | The image runs as root. Make sure you built from this Dockerfile (`USER 101`). |
| Page loads but the car color didn't change | Hard-refresh (Ctrl+Shift+R) to bypass the cache, and rebuild the Docker image after editing `style.css`. |
| Port 8080 already in use | Map another host port, e.g. `-p 9090:8080`. |

## Browser support

Uses `color-mix()`, `@property`, and the individual `translate`/`rotate` CSS properties, all supported in current Chrome, Edge, Firefox and Safari. If someone has "reduce motion" enabled on their device, the entrance animation, engine vibration and speed lines are switched off.
